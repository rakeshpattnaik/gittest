package com.camunda.demo.app.DemoApplication;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class ActionByManager implements JavaDelegate {

	@Override
	public void execute(DelegateExecution arg0) throws Exception {
		Object checkBoxStatus = arg0.getVariable("approved");

	}

}
