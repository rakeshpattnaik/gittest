
package cust.survey.camunda.delegate;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import cust.survey.camunda.model.CustomerData;

public class ProcessRating implements JavaDelegate {

  private final static Logger LOG = Logger.getLogger(ProcessRating.class.getName());

  public void execute(DelegateExecution execution) throws Exception {

    CustomerData customerData = (CustomerData) execution.getVariable("customerData");

    LOG.info("\n\n\n    processing rating for customer "+customerData+"\n\n\n");

  }

}
