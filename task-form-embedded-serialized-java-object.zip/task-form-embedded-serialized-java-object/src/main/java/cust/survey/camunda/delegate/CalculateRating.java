
package cust.survey.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import cust.survey.camunda.model.CustomerData;

public class CalculateRating implements JavaDelegate {

  public void execute(DelegateExecution execution) throws Exception {

    CustomerData customerData = (CustomerData) execution.getVariable("customerData");

    // if the customer is not a VIP customer, the rating can be calculated automatically
    if(!customerData.isVip()) {

      // here we would execute some complex rating logic
      customerData.setRating(0.5f);

      execution.setVariable("ratingCreated", true);

    }
    else {
      execution.setVariable("ratingCreated", false);
    }

  }

}
