package com.atm.sim;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	int amount = 50;
        System.out.println( "Hello World!" +500/10);
    }
}
