package com.atm.sim;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;



public class AtmOprations {

	private static int current_baance = 0;
	private static List<AtmSimObj> inputTrnsactionAmountList;
	private static List<AtmSimObj> acceptedDenominationAmountList;
	private static Date transactionDate;
	private static String BLANK_SPACE = " ";
	private static AtmSimObj atmObj;
	private static String DEPOSIT = "Deposit";
	private static String WITHDRAW = "Withdraw";

	//InputStreamReader to read the entered text
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);

	public static void main(String[] args) throws IOException {

		//Setting the transaction date to current date
		transactionDate = new Date();
		//Creating the instance and executing the program
		AtmOprations atmOprObj = new AtmOprations();
		atmOprObj.atmOprationMenu();

	}

	public void atmOprationMenu() throws IOException {

		int selectOption;
		// Display the ATM menu option 
		System.out.println("------------------------");
		System.out.println("1. Deposit");
		System.out.println("2. Withdraw");
		System.out.println("3. Display Balance");
		System.out.println("4. Mini Statement");
		System.out.println("5. Exit");
		System.out.println("------------------------");
		System.out.println("Select one option: ");

		String inputOption = br.readLine();
		selectOption = Integer.parseInt(inputOption);

		switch(selectOption) {

		case 1:
			depositAmount();
			atmOprationMenu();
			break;
		case 2:
			withDrawAmount();
			atmOprationMenu();
			break;
		case 3:
			displayBalance();
			atmOprationMenu();
			break;
		case 4:
			printMiniStatement();
			atmOprationMenu();
			break;
		case 5:
			System.out.println("Have a good day");
		}
	}

	private void depositAmount() throws IOException
	{
		int totalDepositAmount = 0;
		System.out.println("Enter ccy to deposit terminated by. e.g. 10 20 50 .");
		String depositAmount = br.readLine();
		String[] depositAmountArray = depositAmount.split(BLANK_SPACE);

		//Initialize the declared ArrayList
		inputTrnsactionAmountList = new ArrayList<AtmSimObj>();
		acceptedDenominationAmountList = new ArrayList<AtmSimObj>();

		//Loop the input amount and set in the ArrayList
		for(int i= 0; i < depositAmountArray.length; i++) {

			//Adding the transaction details to the atmObj
			atmObj = new AtmSimObj();
			atmObj.setTranasactionDate(transactionDate);
			atmObj.setTransactionAmount(Integer.parseInt(depositAmountArray[i]));
			atmObj.setTransactionStatus(DEPOSIT);

			//Adding the input transaction amount details to inputTrnsactionAmountList list
			inputTrnsactionAmountList.add(atmObj);

			//Check the amount denomination - $10 , $20 & $50
			if(((inputTrnsactionAmountList.get(i).getTransactionAmount() / 10 == 1) && (inputTrnsactionAmountList.get(i).getTransactionAmount() % 10 == 0))
					||((inputTrnsactionAmountList.get(i).getTransactionAmount() / 20 == 1)&& (inputTrnsactionAmountList.get(i).getTransactionAmount() % 20 == 0))
					||((inputTrnsactionAmountList.get(i).getTransactionAmount() / 50 == 1)&& (inputTrnsactionAmountList.get(i).getTransactionAmount() % 50 == 0))) {

				//Printing the amount - if accepted
				System.out.println("Accepted: "+inputTrnsactionAmountList.get(i).getTransactionAmount());
				//Adding the amount details entered by user to list
				acceptedDenominationAmountList.add(atmObj);
				//Adding total amount entered by user
				totalDepositAmount += inputTrnsactionAmountList.get(i).getTransactionAmount();
			}
			else {
				System.out.println("Invalid denomiation: $"+inputTrnsactionAmountList.get(i).getTransactionAmount());
			}


		}
		//Sorting the acceptedDenominationAmount list in descending order
		Collections.sort(acceptedDenominationAmountList, new SortByTransactionAmount());
		//Setting the final balance
		current_baance += totalDepositAmount;
		System.out.println("Total balance after deposit: "+current_baance);

	}

	private void displayBalance() throws IOException {
		System.out.println("Available balance : "+ current_baance);
	}

	private void withDrawAmount() throws IOException {

		int withDrawalAmount = 0;
		System.out.println("Enter amount to withdraw ");
		String withdrawAmount = br.readLine();
		withDrawalAmount = Integer.parseInt(withdrawAmount);

		//Condition -1 : if the withdraw amount requested is one of entered denomination
		if(acceptedDenominationAmountList.contains(withDrawalAmount)) {
			System.out.println("Dispensing "+withDrawalAmount+"$");
		}
		//Condition -2 : if requested amount is more than total balance available
		else if(withDrawalAmount > current_baance) {
			System.out.println(
					"You have inssuficient amount to dispense \n"+
							"Total balance available : "+current_baance+"$"+"\n"+
							"Requested withdrawal amount : "+withDrawalAmount+"$"
					);
		}
		//Condition -3 : if the requested amount is not denomination of 10 the amount can not be dispensed
		else if(withDrawalAmount % 10 != 0) {
			System.out.println("The request withdraw amount can not be dispensed : "+ withDrawalAmount+"$");
		}
		else {
			for(int j = 0; j < acceptedDenominationAmountList.size(); j++) {
				if(withDrawalAmount - acceptedDenominationAmountList.get(j).getTransactionAmount() == 0) {
					System.out.println("Dispensing "+acceptedDenominationAmountList.get(j).getTransactionAmount());
					current_baance -= acceptedDenominationAmountList.get(j).getTransactionAmount();
					break;
				}
				if(withDrawalAmount - acceptedDenominationAmountList.get(j).getTransactionAmount() > 0 ) {
					System.out.println("Dispensing "+acceptedDenominationAmountList.get(j).getTransactionAmount());
					withDrawalAmount = withDrawalAmount - acceptedDenominationAmountList.get(j).getTransactionAmount();
					current_baance -= acceptedDenominationAmountList.get(j).getTransactionAmount();
				}
			}
		}
	}
	
	private void printMiniStatement() {
		
		System.out.println("--------------------------------------------------------------------");
		System.out.println("Date Time"+"\t"+"Transaction"+"\t"+"Amount"+"\t"+"Closing Balance");
		System.out.println("--------------------------------------------------------------------");
		System.out.println(atmObj.getTranasactionDate()+"\t"+atmObj.getTransactionStatus()+"\t"+atmObj.getTransactionAmount()+"\t"+current_baance);
		System.out.println("--------------------------------------------------------------------");
		
	}

}



