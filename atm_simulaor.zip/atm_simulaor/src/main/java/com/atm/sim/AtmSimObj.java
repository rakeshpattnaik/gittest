package com.atm.sim;

import java.io.Serializable;
import java.util.Date;

public class AtmSimObj implements Serializable{

	/**
	 * Default serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private int transactionAmount;
	private String transactionStatus;
	private Date tranasactionDate;
	public int getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public Date getTranasactionDate() {
		return tranasactionDate;
	}
	public void setTranasactionDate(Date tranasactionDate) {
		this.tranasactionDate = tranasactionDate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tranasactionDate == null) ? 0 : tranasactionDate.hashCode());
		result = prime * result + transactionAmount;
		result = prime * result + ((transactionStatus == null) ? 0 : transactionStatus.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AtmSimObj other = (AtmSimObj) obj;
		if (tranasactionDate == null) {
			if (other.tranasactionDate != null)
				return false;
		} else if (!tranasactionDate.equals(other.tranasactionDate))
			return false;
		if (transactionAmount != other.transactionAmount)
			return false;
		if (transactionStatus == null) {
			if (other.transactionStatus != null)
				return false;
		} else if (!transactionStatus.equals(other.transactionStatus))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AtmSimObj [transactionAmount=" + transactionAmount + ", transactionStatus=" + transactionStatus
				+ ", tranasactionDate=" + tranasactionDate + "]";
	}
	
	
}
