package com.atm.sim;

import java.util.Comparator;

public class SortByTransactionAmount implements Comparator<AtmSimObj>{

	//Sort by transaction amount - descending
	public int compare(AtmSimObj o1, AtmSimObj o2) {
		
		return o2.getTransactionAmount() - o1.getTransactionAmount();
	}

}
