package com.at.sim.deposit;

public class DepositAmount {

}
